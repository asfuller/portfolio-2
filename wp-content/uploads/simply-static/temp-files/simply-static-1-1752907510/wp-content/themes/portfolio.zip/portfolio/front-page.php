<?php
	get_header();
			function featured_img_url() {
				if (has_post_thumbnail()) {
					the_post_thumbnail_url();
				}
			}
?>
<!--Content Here--->
<?php 
get_footer();
?>