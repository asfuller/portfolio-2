<div class="container mx-auto">
<?php
the_content();
?>
</div>