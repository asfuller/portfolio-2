<!DOCTYPE html>
<html lang="en"> 
<head>
    <!--<title><?php the_title(); ?></title>-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Nebulyn official website">
    <meta name="author" content="Alex Fuller">    
    <link rel="shortcut icon" href="images/logo.png"> 

	<?php
	wp_head();
	?>

</head> 

<body>
	<!--Needed Code-->
	<?php //wp_nav_menu( array( 'theme_location' => 'mobile-menu' ) ); ?> <!--main menu nav-->
	<?php //bloginfo('url'); ?> <!--HREF for Site title-->
	<?php //echo get_bloginfo('name'); ?> <!---Blog Name inside a class--->

    <header class="header">
      <div class="container">
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="<?php bloginfo('url'); ?>"><?php echo get_bloginfo('name'); ?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Link</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#">Disabled</a>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0">
                <input class="form-control mr-sm-2" type="search" placeholder="Search">
                <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
        </div>
        </nav>
      </div>
    </header>